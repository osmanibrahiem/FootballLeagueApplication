package io.osman.football.league.ui.listener;

public interface OnRecyclerItemClickedListener<T> {

    void onClick(T t);
}
